package hw11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

class Person implements Serializable {
	String name;
	String phone;
	String birth;
	String email;
	
	public Person(String name, String phone, String birth, String email) {
		this.name = name;
		this.phone = phone;
		this.birth = birth;
		this.email = email;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getBirth() {
		return birth;
	}
	
	public void setBirth(String birth) {
		this.birth = birth;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String toString() {
		return "Person [name=" + name + "] [phone=" + phone + "] [birthdate=" + birth + "] [email=" + email + "]";
	}
	

}
public class Test {
	
	public static void main(String[] args) {
		boolean done = false;
		int selection;
		Scanner input = new Scanner(System.in);
		String name;
		String phone;
		String birth;
		String email;
		while(!done) {
			
			System.out.print("Select an action:\n1: Add information into a file\n2: Retrieve information from a file and display them\n3: Delete information\n4: Update information\n5: Exit\nYour Input:");
			selection = input.nextInt();
			switch (selection) {
			case 1: {
				System.out.print("Insert name:");
				name = input.next();
				System.out.print("Insert phone number:");
				phone = input.next();
				System.out.print("Insert birth date:");
				birth = input.next();
				System.out.print("Insert email:");
				email = input.next();
				try {
					writeToFile(new Person(name,phone,birth,email));
				} catch (IOException e) {
					e.getStackTrace();
				}
			}
			case 2: {
				try {
					readFile();
				} catch (ClassNotFoundException | IOException e) {
					System.out.println(e.getMessage());
				}
			}
			case 3: {
				//unsure how to do
			}
			case 4: {
				//unsure how to do
			}
			case 5: done = true;
			}
		}
	}
	
	public static void writeToFile(Person p) throws IOException {
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("Person.bin"));
	
		objectOutputStream.writeObject(p);
	}
	
	public static void readFile() throws IOException, ClassNotFoundException {
		ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("Person.bin"));
	
		Person name = (Person) objectInputStream.readObject();
		System.out.println(name);
	}
}